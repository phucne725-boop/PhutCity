PHUT CITY TEST 1.1.0 - SOURCE PROJECT

Included:
- Scoreboard enabled on join: name, job, corporation, account balance.
- Wallet Emerald (plugin-marked) opens withdrawal GUI.
- Withdrawal creates plugin-marked PAPER cash; right-click deposits it.
- /pay <player> <amount> (OP / phutcity.admin)
- /money, /phone, /job (admin test setter)
- /blocktool set market | info | remove
- Market shelves: right-click assigned block to browse.
- Seller holds item, looks at shelf, runs /market stock <price>.
- Buyer clicks listing; money transfers from buyer account to seller account.
- YAML persistence for balances, jobs, corporation display names, shelf assignments and listings.

IMPORTANT:
This is a new test implementation reconstructed from the available compiled JAR context, not a verified rebuild of your original source.
Corporation management and the full contacts/messages/calls phone system are NOT implemented in this 1.1.0 source.
Build with Java 25 and Paper API 26.3 using GitHub Actions workflow.
The compiled JAR was not built in this environment because Java 25 / Paper API artifacts are unavailable here.


CHANGE IN THIS FIX:
- Removed account balance from the scoreboard. It now shows only PHUT CITY, player name, job, and corporation.
- Build workflow pins Gradle 9.1.0 and Java 25.
