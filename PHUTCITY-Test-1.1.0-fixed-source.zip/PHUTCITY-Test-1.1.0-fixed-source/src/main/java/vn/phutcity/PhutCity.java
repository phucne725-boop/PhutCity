package vn.phutcity;

import org.bukkit.*;
import org.bukkit.block.Block;
import org.bukkit.command.*;
import org.bukkit.entity.Player;
import org.bukkit.event.*;
import org.bukkit.event.block.Action;
import org.bukkit.event.inventory.*;
import org.bukkit.event.player.*;
import org.bukkit.inventory.*;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.scoreboard.*;
import org.bukkit.NamespacedKey;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

public final class PhutCity extends JavaPlugin implements Listener, CommandExecutor {
    private NamespacedKey cashKey, walletKey;
    private final Map<UUID, Long> balances = new HashMap<>();
    private final Map<UUID, String> jobs = new HashMap<>();
    private final Map<String, String> blockFunctions = new HashMap<>();
    private final Map<String, List<Listing>> markets = new HashMap<>();
    private final Map<UUID, String> chatInput = new ConcurrentHashMap<>();
    private final Map<UUID, String> pendingMarket = new ConcurrentHashMap<>();
    private final Map<UUID, String> waitingWithdraw = new ConcurrentHashMap<>();
    private final Map<UUID, String> corporations = new HashMap<>();
    private final Map<UUID, String> phoneNumbers = new HashMap<>();
    private final Map<UUID, String> guiOwners = new HashMap<>();

    private static final String PHONE_TITLE = "§8P Phone";
    private static final String MARKET_TITLE = "§8Kệ Market";
    private static final String WALLET_TITLE = "§8Ví tiền PHUT CITY";

    private static final class Listing {
        UUID seller;
        ItemStack item;
        long price;
        Listing(UUID seller, ItemStack item, long price) {
            this.seller = seller; this.item = item.clone(); this.price = price;
        }
    }

    @Override public void onEnable() {
        cashKey = new NamespacedKey(this, "phut_cash");
        walletKey = new NamespacedKey(this, "phut_wallet");
        loadData();
        for (String cmd : List.of("pay", "money", "phone", "blocktool", "job", "market")) {
            PluginCommand c = getCommand(cmd);
            if (c != null) c.setExecutor(this);
        }
        getServer().getPluginManager().registerEvents(this, this);
        for (Player p : Bukkit.getOnlinePlayers()) {
            ensureWallet(p);
            updateBoard(p);
        }
        getLogger().info("PHUT CITY Test 1.1.0 enabled.");
    }

    @Override public void onDisable() { saveData(); }

    private void loadData() {
        saveDefaultConfig();
        for (String s : getConfig().getStringList("balances")) try {
            String[] a=s.split("=",2); balances.put(UUID.fromString(a[0]), Long.parseLong(a[1]));
        } catch (Exception ignored) {}
        for (String s : getConfig().getStringList("jobs")) try {
            String[] a=s.split("=",2); jobs.put(UUID.fromString(a[0]), a[1]);
        } catch (Exception ignored) {}
        for (String s : getConfig().getStringList("corporations")) try {
            String[] a=s.split("=",2); corporations.put(UUID.fromString(a[0]), a[1]);
        } catch (Exception ignored) {}
        for (String s : getConfig().getStringList("blocks")) try {
            String[] a=s.split("\\|",2); blockFunctions.put(a[0], a[1]);
        } catch (Exception ignored) {}
        for (String s : getConfig().getStringList("listings")) try {
            String[] a=s.split("\\|",4);
            UUID seller=UUID.fromString(a[1]);
            long price=Long.parseLong(a[2]);
            ItemStack item=ItemStack.deserializeBytes(Base64.getDecoder().decode(a[3]));
            markets.computeIfAbsent(a[0], k->new ArrayList<>()).add(new Listing(seller,item,price));
        } catch (Exception ex) { getLogger().warning("Skipped invalid market listing: "+ex.getMessage()); }
    }

    private void saveData() {
        List<String> b=new ArrayList<>(), j=new ArrayList<>(), c=new ArrayList<>(), bl=new ArrayList<>(), ls=new ArrayList<>();
        balances.forEach((k,v)->b.add(k+"="+v));
        jobs.forEach((k,v)->j.add(k+"="+v));
        corporations.forEach((k,v)->c.add(k+"="+v));
        blockFunctions.forEach((k,v)->bl.add(k+"|"+v));
        markets.forEach((key,list)->list.forEach(l->ls.add(key+"|"+l.seller+"|"+l.price+"|"+Base64.getEncoder().encodeToString(l.item.serializeAsBytes()))));
        getConfig().set("balances",b); getConfig().set("jobs",j); getConfig().set("corporations",c);
        getConfig().set("blocks",bl); getConfig().set("listings",ls);
        saveConfig();
    }

    private long balance(UUID id) { return balances.getOrDefault(id, 0L); }
    private void setBalance(UUID id,long amount) { balances.put(id,Math.max(0,amount)); }
    private String blockKey(Block b) { return b.getWorld().getUID()+":"+b.getX()+":"+b.getY()+":"+b.getZ(); }
    private boolean admin(CommandSender s) { return s.isOp() || s.hasPermission("phutcity.admin"); }
    private void msg(CommandSender s,String m) { s.sendMessage("§b[PHUT CITY] §f"+m); }

    private ItemStack named(Material mat,String name,String lore) {
        ItemStack it=new ItemStack(mat); ItemMeta meta=it.getItemMeta();
        meta.setDisplayName(name); if(lore!=null) meta.setLore(List.of(lore.split("\n")));
        it.setItemMeta(meta); return it;
    }
    private ItemStack wallet() {
        ItemStack it=named(Material.EMERALD,"§aVí tiền","§7Chuột phải để rút tiền từ tài khoản");
        ItemMeta m=it.getItemMeta(); m.getPersistentDataContainer().set(walletKey,PersistentDataType.BYTE,(byte)1); it.setItemMeta(m); return it;
    }
    private boolean isWallet(ItemStack it) {
        return it!=null && it.hasItemMeta() && it.getItemMeta().getPersistentDataContainer().has(walletKey,PersistentDataType.BYTE);
    }
    private ItemStack cash(long amount) {
        ItemStack it=named(Material.PAPER,"§f"+amount+"P","§7Tiền mặt PHUT CITY\n§8Chuột phải để nạp vào tài khoản");
        ItemMeta m=it.getItemMeta(); m.getPersistentDataContainer().set(cashKey,PersistentDataType.LONG,amount); it.setItemMeta(m); return it;
    }
    private long cashValue(ItemStack it) {
        if(it==null || !it.hasItemMeta()) return -1;
        Long n=it.getItemMeta().getPersistentDataContainer().get(cashKey,PersistentDataType.LONG);
        return n==null?-1:n;
    }
    private void ensureWallet(Player p) {
        boolean found=false;
        for(ItemStack it:p.getInventory().getContents()) if(isWallet(it)){found=true;break;}
        if(!found) p.getInventory().addItem(wallet());
    }

    @EventHandler public void onJoin(PlayerJoinEvent e) {
        ensureWallet(e.getPlayer()); updateBoard(e.getPlayer());
    }
    @EventHandler public void onQuit(PlayerQuitEvent e) {
        chatInput.remove(e.getPlayer().getUniqueId()); pendingMarket.remove(e.getPlayer().getUniqueId());
        waitingWithdraw.remove(e.getPlayer().getUniqueId()); guiOwners.remove(e.getPlayer().getUniqueId());
        saveData();
    }
    @EventHandler public void onDrop(PlayerDropItemEvent e) {
        if(isWallet(e.getItemDrop().getItemStack())) e.setCancelled(true);
        if(cashValue(e.getItemDrop().getItemStack())>=0) { /* cash may be dropped */ }
    }
    @EventHandler public void onClick(InventoryClickEvent e) {
        if(!(e.getWhoClicked() instanceof Player p)) return;
        if(isWallet(e.getCurrentItem()) || isWallet(e.getCursor())) e.setCancelled(true);
        String title=e.getView().getTitle();
        if(title.equals(PHONE_TITLE) || title.equals(WALLET_TITLE) || title.equals(MARKET_TITLE)) {
            e.setCancelled(true);
            if(e.getClickedInventory()==null || e.getClickedInventory()!=e.getView().getTopInventory()) return;
            int slot=e.getRawSlot();
            if(title.equals(PHONE_TITLE)) {
                if(slot==10) openWallet(p);
                if(slot==13) msg(p,"Số dư tài khoản: §a"+balance(p.getUniqueId())+"P");
                if(slot==16) msg(p,"Công việc: "+jobs.getOrDefault(p.getUniqueId(),"Chưa có")+" | Tập đoàn: "+corporations.getOrDefault(p.getUniqueId(),"Không có"));
            } else if(title.equals(WALLET_TITLE)) {
                if(slot==13) {
                    waitingWithdraw.put(p.getUniqueId(),"withdraw");
                    p.closeInventory(); msg(p,"Nhập số tiền muốn rút vào chat. Gõ 'huy' để hủy.");
                }
            } else if(title.equals(MARKET_TITLE)) {
                String key=guiOwners.get(p.getUniqueId());
                List<Listing> list=markets.getOrDefault(key,List.of());
                if(slot>=0 && slot<list.size()) buy(p,key,slot);
            }
            return;
        }
    }
    @EventHandler public void onDrag(InventoryDragEvent e) {
        String title=e.getView().getTitle();
        if(title.equals(PHONE_TITLE)||title.equals(WALLET_TITLE)||title.equals(MARKET_TITLE)) e.setCancelled(true);
        if(isWallet(e.getOldCursor())) e.setCancelled(true);
    }
    @EventHandler public void onInteract(PlayerInteractEvent e) {
        if(e.getHand()!=EquipmentSlot.HAND) return;
        Player p=e.getPlayer(); ItemStack held=e.getItem();
        if(e.getAction()==Action.RIGHT_CLICK_AIR || e.getAction()==Action.RIGHT_CLICK_BLOCK) {
            if(isWallet(held)) { e.setCancelled(true); openWallet(p); return; }
            long v=cashValue(held);
            if(v>0) {
                e.setCancelled(true);
                if(balance(p.getUniqueId())>Long.MAX_VALUE-v){msg(p,"Số dư vượt giới hạn.");return;}
                setBalance(p.getUniqueId(),balance(p.getUniqueId())+v);
                if(held.getAmount()>1) held.setAmount(held.getAmount()-1); else p.getInventory().setItemInMainHand(null);
                msg(p,"Đã nạp §a"+v+"P§f vào tài khoản."); updateBoard(p); saveData(); return;
            }
            if(e.getClickedBlock()!=null) {
                String key=blockKey(e.getClickedBlock());
                if("market".equals(blockFunctions.get(key))) { e.setCancelled(true); openMarket(p,key); }
            }
        }
    }

    @EventHandler public void onChat(AsyncPlayerChatEvent e) {
        UUID id=e.getPlayer().getUniqueId();
        String mode=waitingWithdraw.remove(id);
        if(mode==null) mode=chatInput.remove(id);
        if(mode==null) return;
        e.setCancelled(true);
        String input=e.getMessage().trim();
        String finalMode=mode;
        Bukkit.getScheduler().runTask(this,()->{
            Player p=Bukkit.getPlayer(id); if(p==null)return;
            if(input.equalsIgnoreCase("huy")){msg(p,"Đã hủy.");return;}
            if(finalMode.equals("withdraw")) {
                long amount=parseAmount(input);
                if(amount<=0){msg(p,"Số tiền không hợp lệ.");return;}
                if(balance(id)<amount){msg(p,"Tài khoản không đủ tiền.");return;}
                setBalance(id,balance(id)-amount);
                Map<Integer,ItemStack> left=p.getInventory().addItem(cash(amount));
                if(!left.isEmpty()){setBalance(id,balance(id)+amount);msg(p,"Túi đồ đầy, đã hoàn tiền.");}
                else msg(p,"Đã rút §a"+amount+"P§f thành tiền mặt.");
                updateBoard(p);saveData();
            }
        });
    }

    private long parseAmount(String s) {
        try { String t=s.toLowerCase(Locale.ROOT).replace("p","").replace(",","").replace(".","").trim(); return Long.parseLong(t); }
        catch(Exception e){return -1;}
    }
    private void openWallet(Player p) {
        Inventory inv=Bukkit.createInventory(null,27,WALLET_TITLE);
        inv.setItem(13,named(Material.PAPER,"§eRút tiền","§7Nhấn để nhập số tiền muốn rút"));
        p.openInventory(inv);
    }
    private void openPhone(Player p) {
        Inventory inv=Bukkit.createInventory(null,27,PHONE_TITLE);
        inv.setItem(10,named(Material.EMERALD,"§aVí tiền","§7Rút tiền mặt"));
        inv.setItem(13,named(Material.GOLD_INGOT,"§eNgân hàng","§7Xem số dư tài khoản: "+balance(p.getUniqueId())+"P"));
        inv.setItem(16,named(Material.PLAYER_HEAD,"§bThông tin","§7Công việc và tập đoàn"));
        p.openInventory(inv);
    }
    private void openMarket(Player p,String key) {
        guiOwners.put(p.getUniqueId(),key);
        Inventory inv=Bukkit.createInventory(null,54,MARKET_TITLE);
        List<Listing> list=markets.getOrDefault(key,List.of());
        for(int i=0;i<Math.min(45,list.size());i++){
            Listing l=list.get(i); ItemStack display=l.item.clone(); ItemMeta m=display.getItemMeta();
            List<String> lore=m.hasLore()?new ArrayList<>(m.getLore()):new ArrayList<>();
            lore.add("§7Giá: §a"+l.price+"P"); lore.add("§7Người bán: §f"+Bukkit.getOfflinePlayer(l.seller).getName());
            lore.add("§eNhấn để mua");
            m.setLore(lore); display.setItemMeta(m); inv.setItem(i,display);
        }
        inv.setItem(49,named(Material.BOOK,"§eKệ Market","§7Số mặt hàng: "+list.size()+"\n§7Người bán: dùng /market stock <giá> khi cầm đồ và nhìn vào kệ"));
        p.openInventory(inv);
    }
    private void buy(Player p,String key,int slot) {
        List<Listing> list=markets.get(key); if(list==null || slot>=list.size())return;
        Listing l=list.get(slot);
        if(l.seller.equals(p.getUniqueId())){msg(p,"Bạn không thể mua hàng của chính mình.");return;}
        if(balance(p.getUniqueId())<l.price){msg(p,"Tài khoản không đủ tiền.");return;}
        HashMap<Integer,ItemStack> leftovers=p.getInventory().addItem(l.item.clone());
        if(!leftovers.isEmpty()){msg(p,"Túi đồ không đủ chỗ.");return;}
        setBalance(p.getUniqueId(),balance(p.getUniqueId())-l.price);
        setBalance(l.seller,balance(l.seller)+l.price);
        list.remove(slot); msg(p,"Đã mua hàng với giá §a"+l.price+"P§f.");
        Player seller=Bukkit.getPlayer(l.seller); if(seller!=null)msg(seller,"Có người vừa mua hàng của bạn: §a+"+l.price+"P");
        updateBoard(p); if(seller!=null)updateBoard(seller); saveData(); p.closeInventory();
    }
    private void updateBoard(Player p) {
        Scoreboard board=Bukkit.getScoreboardManager().getNewScoreboard();
        Objective obj=board.registerNewObjective("phutcity","dummy","§b§lPHUT CITY");
        obj.setDisplaySlot(DisplaySlot.SIDEBAR);
        obj.getScore("§fTên: §b"+p.getName()).setScore(4);
        obj.getScore("§fCông việc: §e"+jobs.getOrDefault(p.getUniqueId(),"Chưa có")).setScore(3);
        obj.getScore("§fTập đoàn: §a"+corporations.getOrDefault(p.getUniqueId(),"Không có")).setScore(2);
        p.setScoreboard(board);
    }

    @Override public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        String c=command.getName().toLowerCase(Locale.ROOT);
        if(c.equals("pay")) {
            if(!admin(sender)){msg(sender,"Bạn không có quyền.");return true;}
            if(args.length!=2){msg(sender,"Dùng: /pay <người chơi> <số tiền>");return true;}
            Player target=Bukkit.getPlayerExact(args[0]); long amount=parseAmount(args[1]);
            if(target==null||amount<=0){msg(sender,"Người chơi hoặc số tiền không hợp lệ.");return true;}
            setBalance(target.getUniqueId(),balance(target.getUniqueId())+amount); updateBoard(target);saveData();
            msg(sender,"Đã cộng "+amount+"P cho "+target.getName());msg(target,"Bạn nhận được §a"+amount+"P§f.");return true;
        }
        if(c.equals("money")){msg(sender,"Số dư tài khoản: §a"+balance(sender instanceof Player p?p.getUniqueId():new UUID(0,0))+"P");return true;}
        if(c.equals("phone")){if(sender instanceof Player p)openPhone(p);return true;}
        if(c.equals("job")) {
            if(!(sender instanceof Player p))return true;
            if(!admin(sender)){msg(sender,"Chỉ admin được đặt công việc trong bản test.");return true;}
            if(args.length==0){msg(sender,"Dùng: /job <tên công việc>");return true;}
            jobs.put(p.getUniqueId(),String.join(" ",args));updateBoard(p);saveData();msg(p,"Đã cập nhật công việc.");return true;
        }
        if(c.equals("blocktool")) {
            if(!admin(sender)){msg(sender,"Bạn không có quyền.");return true;}
            if(!(sender instanceof Player p)){msg(sender,"Lệnh này cần người chơi.");return true;}
            if(args.length==0){msg(p,"Dùng: /blocktool set market | /blocktool info | /blocktool remove");return true;}
            Block b=p.getTargetBlockExact(6);
            if(b==null){msg(p,"Hãy nhìn vào block trong phạm vi 6 block.");return true;}
            String key=blockKey(b);
            if(args[0].equalsIgnoreCase("set")&&args.length>=2&&args[1].equalsIgnoreCase("market")){
                blockFunctions.put(key,"market");saveData();msg(p,"Đã gán block này thành Kệ Market.");return true;
            }
            if(args[0].equalsIgnoreCase("info")){msg(p,"Chức năng: "+blockFunctions.getOrDefault(key,"Chưa gán"));return true;}
            if(args[0].equalsIgnoreCase("remove")){blockFunctions.remove(key);markets.remove(key);saveData();msg(p,"Đã gỡ chức năng khỏi block.");return true;}
            msg(p,"Dùng: /blocktool set market | /blocktool info | /blocktool remove");return true;
        }
        if(c.equals("market")) {
            if(!(sender instanceof Player p))return true;
            if(args.length==0){Block b=p.getTargetBlockExact(6);if(b==null){msg(p,"Hãy nhìn vào kệ Market.");return true;}String key=blockKey(b);if(!"market".equals(blockFunctions.get(key))){msg(p,"Block này chưa được gán Kệ Market.");return true;}openMarket(p,key);return true;}
            if(args[0].equalsIgnoreCase("stock")) {
                if(args.length!=2){msg(p,"Dùng: cầm món đồ và nhìn vào kệ, sau đó /market stock <giá>");return true;}
                Block b=p.getTargetBlockExact(6); if(b==null){msg(p,"Hãy nhìn vào kệ Market.");return true;}
                String key=blockKey(b); if(!"market".equals(blockFunctions.get(key))){msg(p,"Block này chưa phải Kệ Market.");return true;}
                ItemStack hand=p.getInventory().getItemInMainHand(); long price=parseAmount(args[1]);
                if(hand.getType().isAir()||price<=0){msg(p,"Vật phẩm hoặc giá không hợp lệ.");return true;}
                List<Listing> list=markets.computeIfAbsent(key,k->new ArrayList<>());
                if(list.size()>=45){msg(p,"Kệ đã đầy (tối đa 45 mặt hàng).");return true;}
                list.add(new Listing(p.getUniqueId(),hand.clone(),price));p.getInventory().setItemInMainHand(null);
                saveData();msg(p,"Đã đăng "+hand.getType()+" với giá "+price+"P.");return true;
            }
        }
        return true;
    }
}
